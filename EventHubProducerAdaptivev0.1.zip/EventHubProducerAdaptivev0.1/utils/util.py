########################################################################
# Owner: Anuj Singhal
# Created on: 11-10-2021
# Modified by:
# Modified on:
# Description: methods to support application functions
########################################################################

from config.config import *

def get_event_position(filepath):
    logging.info("Getting current event position")
    with open(filepath, 'r') as f:
        try:
            event_position = int(f.read())
            logging.info("Current event position : " + str(event_position))
            print("Current event position : " + str(event_position))
            return event_position
        except Exception as e:
            logging.info("Exception Occured while getting event position: ")
            print(e)
            return 0


def set_event_position(filepath, new_event_position):
    with open(filepath, 'w') as f:
        try:
            f.write(str(new_event_position))
            logging.info("Event position commit successfully with new_event_position : " + str(new_event_position))
            print("Event position commit successfully with new_event_position : " + str(new_event_position))
            return 1
        except Exception as e:
            logging.info("Exception Occured while commiting event position in file: " + str(new_event_position))
            return 0