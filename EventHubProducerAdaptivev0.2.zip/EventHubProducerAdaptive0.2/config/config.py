########################################################################
# Owner: Anuj Singhal
# Created on: 11-10-2021
# Modified by:
# Modified on:
# Description: configuration file setting variables from .ini file
########################################################################

from configparser import ConfigParser
import logging
from logging.handlers import RotatingFileHandler
import json
import os
from datetime import datetime

#Read config.ini file
config_object = ConfigParser()
config_object.read("config.ini")

def get_log_filepath(folderpath, filename):
    current_time = datetime.now().strftime("%Y%m%d%H%M%S")
    folderpath = folderpath + current_time
    if not os.path.exists(folderpath):
        os.mkdir(folderpath)
    log_filepath = folderpath + "/" + filename
    return log_filepath

#############################  Setting variables from config   #######################################

#Get the connection string
eventinfosend = config_object["EVENTINFO"]
logginginfo = config_object["LOGGINGINFO"]
websocketinfo = config_object["WEBSOCKETINFO"]

LOG_FILENAME = logginginfo["LOG_FILENAME"]
LOG_FILEFOLDER = logginginfo["LOG_FILEFOLDER"]
LOG_FILESIZE = int(logginginfo["LOG_FILESIZE"])
LOG_BACKUPFILES = int(logginginfo["LOG_BACKUPFILES"])
LOG_WRITEMODE = logginginfo["LOG_WRITEMODE"]

EVENT_POSITION_FILEPATH = eventinfosend["EVENT_POSITION_FILEPATH"]
#CONNECTION_STR = eventinfosend["CONNECTION_STR"]
WEBSOCKET_URL = websocketinfo[websocketinfo["WEBSOCKET_ENV"]]

#############################  Setting Logger   #######################################

rfh = logging.handlers.RotatingFileHandler(
    filename=get_log_filepath(LOG_FILEFOLDER, LOG_FILENAME),
    mode=LOG_WRITEMODE,
    maxBytes=LOG_FILESIZE*1024*1024,
    backupCount=LOG_BACKUPFILES,
    encoding=None,
    delay=0
)

logging.basicConfig(format='%(asctime)s :: %(levelname)s :: %(funcName)s :: %(lineno)d \
:: %(message)s', level = logging.INFO, handlers=[rfh])

logging.info("Setting Configurations from config.ini file")

def get_position(filepath):
    with open(filepath, 'r') as f:
        try:
            event_position = int(f.read())
            return event_position
        except Exception as e:
            logging.info("Exception Occured while getting event position: ")
            print(e)
            return 0

def get_websocket_message():
    if websocketinfo["MSG_TYPE"] == "MSG_FROM_POSITION":
        current_eventposition = get_position(EVENT_POSITION_FILEPATH)
        msg = websocketinfo["MSG_FROM_POSITION"].replace("<lasteventposition>", str(current_eventposition))
        return msg
    else:
        return websocketinfo[websocketinfo["MSG_TYPE"]]

