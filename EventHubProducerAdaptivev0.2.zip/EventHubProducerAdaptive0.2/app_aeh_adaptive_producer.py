########################################################################
# Owner: Anuj Singhal
# Created on: 11-10-2021
# Modified by:
# Modified on:
# Description: Main file to get the adaptive live steeaming data
#              from websocket and push into Azure Event hub Events.
########################################################################

from config.config import *
import asyncio
import websockets
import json
from azure.eventhub.aio import EventHubProducerClient
from azure.eventhub import EventData
from utils.util import *
import time
from datetime import datetime

#############################  PUSH EVENT TO AZURE EVENT HUB   #######################################

async def push_event(response, event_type, event_pos):
    connection_str = None
    event_hub = None
    logging.info('Pushing into EventHub now')
    print('Pushing into EventHub now')
    try:
        event_conf = eventinfosend["EVENT_"+event_type].split(",")
        event_namespace = event_conf[0]
        event_hub = event_conf[1]
        connection_str = eventinfosend["CONNECTION_STR_"+event_namespace]
        logging.info("event_namespace - " + event_namespace)
        logging.info("event_hub - " + event_hub)
        logging.info("CONNECTION_STR - " + connection_str)
        #event_hub = None
    except:
        event_hub = None
    if event_hub is not None:
        logging.info("Creating Producer for event hub - " + str(event_hub))
        logging.info("connection_str - " + connection_str)
        producer = EventHubProducerClient.from_connection_string(conn_str=connection_str, eventhub_name=event_hub)
        async with producer:
            logging.info("Create a batch.")
            event_data_batch = await producer.create_batch()

            logging.info("Add events to the batch.")
            event_data_batch.add(EventData(response))

            logging.info("Send the batch of events to the event hub.")
            await producer.send_batch(event_data_batch)
            set_event_position(EVENT_POSITION_FILEPATH, event_pos)
            logging.info("Event batch - DONE!")
            print("Event batch - DONE!")
    else:
        logging.info("Invalid Event Hub in Azure!" + event_type)
        set_event_position(EVENT_POSITION_FILEPATH, event_pos)

#############################  DATA ACQUISITION #######################################

async def get_data():
    async with websockets.connect(WEBSOCKET_URL) as websocket:
        await websocket.send(json.dumps(WEBSOCKET_MSG))
        logging.info("Handshaking Websocket message sent")
        logging.info("Handshaking Message : " + str(WEBSOCKET_MSG))
        #count = 0
        while True:
            logging.info("Waiting for message to receive... ")
            print("Waiting for message to receive... ")
            #time.sleep(1)
            response = await websocket.recv()
            # print(count)
            # count += 1
            # if(count == 10):
            #     raise Exception("Batch Full...")
            logging.info("Message received... ")
            print("Message received... ")
            logging.info(response)
            print(response)
            # response = '''{"service":"StreamingService","method":"subscribe","correlationId":"00000000-0000-0000-0000-004000000006","kind":"NEXT","payload":{"event":{"type":"tradingAccount","payload":{"accountNumber":"A9549142","valuationCurrency":"GBP","accountState":"Active","type":"S","closingOnly":false,"isAutoLiquidate":false,"productType":"CFD","accountType":"Cash","timestamp":"1617297635033"}},"eventPosition":"69984"}}'''
            response_body = json.loads(response)
            if "event" in response_body["payload"].keys():
                event_type = response_body["payload"]["event"]["type"]
                event_pos = int(response_body["payload"]["eventPosition"])
            else:
                raise Exception(str(response_body["payload"]))
            response_body["aehLoadTimestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            response = json.dumps(response_body)
            logging.info("Event Type - " + event_type + " | Event_Position : " + str(event_pos))
            #print(event_type + "|" + str(event_pos))
            print("Event Type - " + event_type + " | Event_Position : " + str(event_pos))
            if event_pos > current_eventposition:
                all_events_list = eventinfosend["ALL_EVENTS"].split(',')
                if (event_type.lower() in all_events_list):
                    #set_event_position(EVENT_POSITION_FILEPATH, event_pos)
                    await push_event(response, event_type.lower(), event_pos)
                else:
                    logging.info("Invalid Event Hub in Azure!" + event_type)
                    set_event_position(EVENT_POSITION_FILEPATH, event_pos)
                    #await push_event(response, "failedevent", event_pos)

if __name__ == '__main__':
    while True:
        logging.info("Producer Started... ")
        print("Producer Started... ")
        WEBSOCKET_MSG = json.loads(get_websocket_message())
        logging.info("WEBSOCKET_URL - " + str(WEBSOCKET_URL))
        logging.info("WEBSOCKET_MSG - " + str(WEBSOCKET_MSG))
        current_eventposition = get_event_position(EVENT_POSITION_FILEPATH)
        logging.info("Commited event position ... " + str(current_eventposition))
        try:
            loop = asyncio.get_event_loop()
            loop.run_until_complete(get_data())
        except Exception as e:
            logging.info("Exception Occured!")
            logging.info(e)
            time.sleep(10)
